<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Php Basics</title>
  </head>
  <body>

    <form class="" action="formprocess.php" method="post">

      <table>
        <tr>
          <td>Name:</td>
          <td><input type="text" name="" value=""> <br></td>
        </tr>

        <tr>
          <td>Address:</td>
          <td><input type="text" name="" value=""> <br></td>
        </tr>

        <tr>
          <td>City:</td>
          <td><input type="text" name="" value=""> <br></td>
        </tr>

        <tr>
          <td><button type="submit" name="button">Submit</button></td>
        </tr>
      </table>
    </form>

  </body>
</html>
